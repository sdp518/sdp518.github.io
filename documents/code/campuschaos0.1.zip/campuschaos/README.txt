To execute the game please run campuschaos.jar

The game does require the Java Runtime Environment to be installed