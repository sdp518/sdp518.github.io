<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SquareSet" tilewidth="128" tileheight="128" tilecount="2" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="128" height="128" source="grass2.png"/>
 </tile>
 <tile id="1">
  <image width="128" height="128" source="restricted.png"/>
 </tile>
</tileset>
