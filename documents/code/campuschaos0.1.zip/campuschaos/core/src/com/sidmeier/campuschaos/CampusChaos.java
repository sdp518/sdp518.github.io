package com.sidmeier.campuschaos;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.sidmeier.campuschaos.utils.Coord;
import com.sidmeier.campuschaos.utils.FontGenerator;

public class CampusChaos extends ApplicationAdapter {

    private Viewport viewport;
    private OrthographicCamera cam;

    private SpriteBatch batch;
    private BitmapFont font;

    private TiledMap tiledMap;
    private OrthogonalTiledMapRenderer renderer;

    private Map map;
    private Stage stage;

    private SectorInformation sectorDisplay;

    /**
     * Instantiates various objects when game is first loaded
     */
	@Override
	public void create () {
	    this.map = new Map();
        this.batch = new SpriteBatch();

        this.font = new FontGenerator().generateFont("core/assets/FreeMonoBold.ttf", 48);

        this.tiledMap = new TmxMapLoader().load("core/assets/SEPRMapSquare.tmx");
        this.renderer = new OrthogonalTiledMapRenderer(this.tiledMap);

        this.cam = new OrthographicCamera();
        this.viewport = new ScreenViewport(this.cam);
        this.viewport.apply();

        this.resize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        Float[] displayedWH = getDisplayValues();

        float displayedMW = displayedWH[0];
        float displayedMH = displayedWH[1];

        this.cam.position.set(this.cam.viewportWidth/2,this.cam.viewportHeight/2,0);
        this.cam.zoom = (displayedMH<displayedMW?displayedMH:displayedMW)  - 0.001f;

        this.sectorDisplay = new SectorInformation(this.batch);
	}

    /**
     * Updates camera position, clears screen and uses renderer to draw map
     */
	@Override
	public void render () {
        this.sectorDisplay.setTileOrigin(this.getTileOrigin(new Coord<Integer,Integer>(18,1)));
        this.stage = new Stage(this.viewport, new SpriteBatch());
        this.stage.addActor(this.sectorDisplay);
        Gdx.input.setInputProcessor(this.stage);
        this.handleInput();
        this.cam.update();

        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        this.renderer.setView(this.cam);
        this.renderer.render();

        this.selectionBox();
        Coord<Integer, Integer> coord = this.getTileCoordinates();

        String sectorName = null;
        if(this.map.sectorAtCoord(coord)) {
            sectorName = this.map.getSector(coord).getName();
            if(Gdx.input.isTouched(0)){
                tileClicked(Gdx.input.getX(),(-Gdx.input.getY() + (this.cam.viewportHeight)));
            }
        }
        if (this.sectorDisplay.isDraw()) {
            this.infoBox();
        }
        this.batch.begin();
        if(sectorName != null){
            this.font.draw(this.batch,sectorName,20,(this.cam.viewportHeight - 20));
        }
        this.batch.end();
        this.stage.draw();
	}

    /**
     * Calls camera controls and clamping, takes user input to exit game
     */
    private void handleInput() {
        /*float camSpeed = 3;    // Camera speed in units per frame
        this.cameraZoom();
        this.cameraTranslate(camSpeed);
        this.edgeScrolling(camSpeed);*/

        // Escape to exit
        if (Gdx.input.isKeyPressed(Input.Keys.ESCAPE)) {
            Gdx.app.exit();
        }

        this.edgeClamping();
    }

    /**
     * Handles user input to zoom camera
     */
    private void cameraZoom() {
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            this.cam.zoom += 0.02;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.Q)) {
            this.cam.zoom -= 0.02;
        }
    }

    /**
     * Handles user input to move camera
     * @param camSpeed Is the speed of the camera movement
     */
    private void cameraTranslate(float camSpeed) {
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            this.cam.translate(-camSpeed, 0, 0);
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            this.cam.translate(camSpeed, 0, 0);
        }
        if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            this.cam.translate(0, -camSpeed, 0);
        }
        if (Gdx.input.isKeyPressed(Input.Keys.UP)) {
            this.cam.translate(0, camSpeed, 0);
        }
    }

    /**
     * Edge scrolling allows camera movement with mouse
     * @param camSpeed Is the speed of the camera movement
     */
    private void edgeScrolling(float camSpeed) {
        float edgePercent = 5;  // Percentage of APP edge that will cause scrolling on mouseover
        float x = Gdx.input.getX();
        float y = Gdx.input.getY();

        float leftEdge = (this.cam.viewportWidth / 100) * edgePercent;
        float rightEdge = this.cam.viewportWidth - leftEdge;
        float bottomEdge = (this.cam.viewportHeight / 100) * edgePercent;
        float topEdge = this.cam.viewportHeight - bottomEdge;

        if (x <= leftEdge) {
            this.cam.translate(-camSpeed, 0, 0);
        } else if (x >= rightEdge) {
            this.cam.translate(camSpeed, 0, 0);
        }

        if (y <= bottomEdge) {
            this.cam.translate(0, camSpeed, 0);
        } else if (y >= topEdge) {
            this.cam.translate(0, -camSpeed, 0);
        }
    }

    /**
     * Ensures camera doesn't leave the edge of the map
     */
    private void edgeClamping() {
        Float[] displayValues = this.getDisplayValues();

        float displayedMW = displayValues[0];
        float displayedMH = displayValues[1];

        this.cam.zoom = (MathUtils.clamp(this.cam.zoom, 1f, (displayedMH<displayedMW?displayedMH:displayedMW)));

        float effectiveViewportWidth = this.cam.viewportWidth * this.cam.zoom;
        float effectiveViewportHeight = this.cam.viewportHeight * this.cam.zoom;

        this.cam.position.x = MathUtils.clamp(this.cam.position.x, effectiveViewportWidth / 2f, (displayValues[2] - effectiveViewportWidth / 2f) - 1);
        this.cam.position.y = MathUtils.clamp(this.cam.position.y, effectiveViewportHeight / 2f, (displayValues[3] - effectiveViewportHeight / 2f) - 1);

        float scale = (Gdx.graphics.getWidth()/(float)Gdx.graphics.getHeight());

        if (scale < 1.7f) {
            this.cam.translate(64,0);
        }
    }

    /**
     * Calculates the map coordinate of the tile containing the passed x and y mouse axis coordinates
     * @param x Is a mouse axis x-coordinate inside the tile who's coordinates are being calculated
     * @param y Is a mouse axis y-coordinate inside the tile who's coordinates are being calculated
     */
    private void tileClicked(float x, float y) {
        Coord<Float,Float> camOffset = this.getCameraOffset();
        Coord<Float,Float> tileDimensions = this.getTileDimensions();

        // Calculates tile coordinate (on map) that mouse is over
        int tileX = (int) ((x + camOffset.getX())/tileDimensions.getX());
        int tileY = (int) ((y + camOffset.getY())/tileDimensions.getY());
        Coord<Integer,Integer> coord = new Coord<Integer, Integer>(tileX, tileY);
        this.sectorDisplay.setSector(this.map.getSector(coord));
    }

    /**
     * Calculates display values for zoom calculations
     * @return Array of [Displayed Map Width, Displayed Map Height, Total Map Width, Total Map Height]
     */
    private Float[] getDisplayValues() {
        TiledMapTileLayer mainLayer = (TiledMapTileLayer)tiledMap.getLayers().get(0);

        /*// Calculates total map dimensions
        float totalMapWidth = mainLayer.getWidth() * mainLayer.getTileWidth();
        float totalMapHeight = (mainLayer.getHeight() * mainLayer.getTileHeight()) - 128;*/
        float totalMapWidth;
        float totalMapHeight;

        if ((Gdx.graphics.getWidth()/Gdx.graphics.getHeight()) < 1.7) {
            // Calculates total map dimensions
            totalMapWidth = mainLayer.getWidth() * mainLayer.getTileWidth();
            totalMapHeight = (mainLayer.getHeight() * mainLayer.getTileHeight());
        }
        else {
            // Calculates total map dimensions
            totalMapWidth = mainLayer.getWidth() * mainLayer.getTileWidth();
            totalMapHeight = (mainLayer.getHeight() * mainLayer.getTileHeight()) - 128;
        }

        // Calculates the displayed Map width and height
        float displayedMW = totalMapWidth/cam.viewportWidth;
        float displayedMH = totalMapHeight/cam.viewportHeight;

        return new Float[]{displayedMW, displayedMH, totalMapWidth, totalMapHeight};
    }

    /**
     * Draws highlight over tile that user is mousing over
     */
    private void selectionBox(){
        Coord<Float,Float> tileDimensions = this.getTileDimensions();
        Coord<Float,Float> tileOrigin = this.getTileOrigin(this.getTileCoordinates());

        // Renders outline and fill of tile highlight
        Gdx.gl.glEnable(GL20.GL_BLEND);  // To allow opacity (alpha channel)
        ShapeRenderer shapeRenderer = new ShapeRenderer();
        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(1, 0, 0, 1);
        shapeRenderer.rect(tileOrigin.getX(), tileOrigin.getY(), tileDimensions.getX(), tileDimensions.getY());
        shapeRenderer.end();
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.setColor(1, 0, 0, 0.5f);
        shapeRenderer.rect(tileOrigin.getX(), tileOrigin.getY(), tileDimensions.getX(), tileDimensions.getY());
        shapeRenderer.end();
    }

    /**
     * Draws information box that is displayed on tile click
     */
    private void infoBox() {
        Coord<Float,Float> tileDimensions = this.getTileDimensions();
        Coord<Float,Float> tileOrigin = this.getTileOrigin(new Coord<Integer,Integer>(18,1));
        Gdx.gl.glEnable(GL20.GL_BLEND);
        ShapeRenderer shaper = new ShapeRenderer();
        shaper.begin(ShapeRenderer.ShapeType.Filled);
        shaper.setColor((131f/255f), (111f/255f), (50f/255f), 1);
        shaper.rect(tileOrigin.getX(), tileOrigin.getY(), 6* tileDimensions.getX(), 4*tileDimensions.getY());
        shaper.end();
        shaper.begin(ShapeRenderer.ShapeType.Filled);
        shaper.setColor((183f/255f), (155f/255f), (70f/255f), 1f);
        shaper.rect(tileOrigin.getX() + 10, tileOrigin.getY() + 10, (6* tileDimensions.getX()) - 20, (4*tileDimensions.getY()) - 20);
        shaper.end();
    }

    /**
     * Takes the x and y of the mouse position and then gets the tile coordinates of the sector where the mouse is.
     * @return Coord<Integer x, Integer y> representing tile coordinates on the map.
     */
    private Coord<Integer,Integer> getTileCoordinates() {
        // Gets mouse offsets from screen 'origin'
        float mouseX = Gdx.input.getX();
        float mouseY = -Gdx.input.getY() + (this.cam.viewportHeight);

        // Gets camera offsets from map origin
        Coord<Float,Float> camOffset = this.getCameraOffset();

        Coord<Float,Float> tileDimensions = this.getTileDimensions();
        // Calculates tile coordinate (on map) that mouse is over
        int tileX = (int) ((mouseX + camOffset.getX())/tileDimensions.getX());
        int tileY = (int) ((mouseY + camOffset.getY())/tileDimensions.getY());
        // Calculates viewport coordinates of bottom left of selected tile

        return new Coord<Integer, Integer>(tileX,tileY);
    }

    /**
     * Calculates the x and y offset of the camera.
     * @return Coord<Float x, Float y> representing the camera offset on the x and y axis.
     */
    private Coord<Float,Float> getCameraOffset() {
        return new Coord<Float,Float>((this.cam.position.x - ((this.cam.viewportWidth/2) * this.cam.zoom)) * (1/this.cam.zoom),
                (this.cam.position.y - ((this.cam.viewportHeight/2) * this.cam.zoom)) * (1/this.cam.zoom));
    }

    /**
     * Calculates a set of values representing the width and height of the tiles on the display
     * for each resolution.
     * @return Coord<Float x, Float y> representing the width (x) and height (y) of the tiles
     */
    private Coord<Float,Float> getTileDimensions() {
        TiledMapTileLayer mainLayer = (TiledMapTileLayer)this.tiledMap.getLayers().get(0);
        float tileWidth = mainLayer.getTileWidth() * (1/this.cam.zoom);
        float tileHeight = mainLayer.getTileHeight() * (1/this.cam.zoom);
        return new Coord<Float,Float>(tileWidth,tileHeight);
    }

    /**
     * Given a Coord of integers representing the coordinates of a tile,
     * returns the value of the bottom left corner of the tile.
     * @param tileCoord The coordinate of the tile on the map.
     * @return Coord<Float x, Float y> representing the screen coordinate of the bottom left corner of the tile.
     */
    private Coord<Float,Float> getTileOrigin(Coord<Integer,Integer> tileCoord) {
        Coord<Float,Float> camOffset = this.getCameraOffset();
        Coord<Float,Float> tileDimensions = this.getTileDimensions();
        float selectX = (tileCoord.getX() * tileDimensions.getX()) - camOffset.getX();
        float selectY = (tileCoord.getY() * tileDimensions.getX()) - camOffset.getY();
        return new Coord<Float,Float> (selectX,selectY);
    }

    /**
     * When the game window is resized, this method makes sure the camera is updated with it.
     * @param width The new width of the window.
     * @param height The new height of the window.
     */
    @Override
    public void resize(int width, int height) {
        this.viewport.update(width,height);
        this.cam.position.set(this.cam.viewportWidth/2,this.cam.viewportHeight/2,0);
    }

    /**
     * Function takes care of memory management.
     */
    @Override
	public void dispose () {
        this.tiledMap.dispose();
        this.renderer.dispose();
        this.batch.dispose();
        this.font.dispose();
        this.stage.dispose();
        this.sectorDisplay.disposeFont();
	}
}
