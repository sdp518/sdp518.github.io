package com.sidmeier.campuschaos;

import com.sidmeier.campuschaos.utils.Coord;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class Map {

    private final HashMap<Coord<Integer,Integer>,Sector> sectorLocations;
    private Coord<Integer, Integer> pvcLocation;

    /**
     * Initialises the map to a HashMap.
     * Containing the coordinates of the sector then the sector instance.
     * Adds to the HashMap the sectors read from file at their location.
     * Also initialises the pro-vice chancellor location.
     */
    public Map() {
        this.sectorLocations = new HashMap<Coord<Integer, Integer>, Sector>();
        this.pvcLocation = new Coord<Integer, Integer>(null, null);

        BufferedReader myReader = null;
        String file = "core/assets/Sectors.txt";
        try {
            this.readSectorsFromFile(myReader, file);
        } catch (IOException e) {
            if (myReader == null) {
                System.out.println("File: Sectors.txt not found");
            } else {
                System.out.println(e.getMessage());
            }
        }
    }

    /**
     * Algorithm to read all the data from the file specified.
     * This algorithm is tweaked to read in the three values from file and create an instance of the sector.
     * This is then put into the HashMap.
     * @param myReader The reader used to convert the input to text.
     * @param file The file name of the file containing the information on each sector.
     * @throws IOException Throws exception when there is more splits than data in the file.
     */
    private void readSectorsFromFile(BufferedReader myReader, String file) throws IOException {
        myReader = new BufferedReader(new FileReader(file));
        String lineRead;
        while ((lineRead = myReader.readLine()) != null) {
            String[] sectorParts = lineRead.split(", ");
            if (sectorParts.length > 4) {
                throw new IOException("File is corrupted.");
            }
            // 0 - Name, 1 - X coord, 2 - Y coord, 3 - bonus
            //System.out.println(sectorParts[0] + ", " + sectorParts[1] + ", " + sectorParts[2]);
            String name = sectorParts[0];
            int x = Integer.parseInt(sectorParts[1]);
            int y = Integer.parseInt(sectorParts[2]);
            int bonus = Integer.parseInt(sectorParts[3]);
            this.addSector(new Coord<Integer,Integer>(x,y), new Sector(name, bonus));
        }
    }

    /**
     * Used to get access to the HashMap containing the data on all the sectors.
     * @return HashMap containing sector data.
     */
    public HashMap<Coord<Integer, Integer>, Sector> getSectorLocations() {
        return this.sectorLocations;
    }

    /**
     * Used to return the pvc sector location.
     * @return The coordinate of Integers which express the sector coordinates of the pvc sector.
     */
    public Coord<Integer, Integer> getPvcLocation() {
        return this.pvcLocation;
    }

    /**
     * Sets the maps instance variable of the pvc location the the parameter given.
     * @param pvcLocation The coordinate of Integers which represent the pvc location.
     */
    public void setPvcLocation(Coord<Integer, Integer> pvcLocation) {
        this.pvcLocation = pvcLocation;
    }

    /**
     * Adds a sector and its coordinates to the HashMap.
     * @param coord The coordinate of Integers which represent the sector coordinates location on the map.
     * @param sector The Sector instance of the sector to be added to the map.
     */
    private void addSector(Coord<Integer, Integer> coord, Sector sector) {
        this.sectorLocations.put(coord, sector);
    }

    /**
     * Given a Coord of Integers relating to the sector coordinates, it then returns the instance of the sector.
     * @param coord The coordinates of the sector that is to be retrieved.
     * @return the instance of the sector referenced by the coordinates.
     */
    public Sector getSector(Coord<Integer, Integer> coord) {
        return this.sectorLocations.get(coord);
    }

    /**
     * A test to see whether, given a set of coordinates, a sector exists or not.
     * @param coord The coordinate of Integers representing a sector location.
     * @return a boolean value representing to whether or not there is a sector at the coordinates.
     */
    public boolean sectorAtCoord(Coord<Integer, Integer> coord) {
        return this.sectorLocations.containsKey(coord);
    }
}
