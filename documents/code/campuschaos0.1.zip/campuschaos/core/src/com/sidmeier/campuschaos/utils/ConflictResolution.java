package com.sidmeier.campuschaos.utils;
import javafx.util.Pair;

import java.util.Random;
public class ConflictResolution {

    /**
     * Calculates the outcome of a conflict
     * @param defendingUnits
     * @param defendMultiplier
     * @param attackingUnits
     * @param attackMultiplier
     * @return an instance of Pair containing the victor and their number of remaining units
     */
    public Pair<Constants.Victor, Integer> resolveConflict(int defendingUnits,
                                                           int defendMultiplier,
                                                           int attackingUnits,
                                                           int attackMultiplier) {

        if ((defendMultiplier <= 0) || (attackMultiplier <= 0)) {
            return null;
        }

        Random rand = new Random();

        while ((attackingUnits > 0) || (defendingUnits > 0)) {
            int sum = (defendingUnits * defendMultiplier) + (attackingUnits * attackMultiplier);
            int n = rand.nextInt(sum);
            if (n <= (defendingUnits * defendMultiplier)) {
                attackingUnits = attackingUnits - 1;
                if (attackingUnits == 0) {
                    return new Pair<Constants.Victor, Integer>(Constants.Victor.DEFENDER, defendingUnits);
                }
            } else {
                defendingUnits = defendingUnits - 1;
                if (defendingUnits == 0) {
                    return new Pair<Constants.Victor, Integer>(Constants.Victor.ATTACKER, attackingUnits);
                }
            }
        }
        return null;
    }

}
