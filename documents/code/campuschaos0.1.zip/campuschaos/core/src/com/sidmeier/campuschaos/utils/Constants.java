package com.sidmeier.campuschaos.utils;

public class Constants {

    private Constants() {
        throw new AssertionError();
    }

    public static final int APP_WIDTH = 1200;
    public static final int APP_HEIGHT = 800;

    public static final int BASE_TROOPS = 5;
    public static final float SECTOR_SCALAR = 0.2f;

    public enum College {
        ALCUIN("Alcuin"), CONSTANTINE("Constantine"), DERWENT("Derwent"),
        GOODRICKE("Goodricke"), HALIFAX("Halifax"), JAMES("James"),
        LANGWITH("Langwith"), VANBRUGH("Vanbrugh"), WENTWORTH("Wentworth");

        private final String name;

        College(String name) {
         this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }

    public enum Victor {
        ATTACKER, DEFENDER
    }

    //TODO Work out if still needed and implement

    public static final int WORLD_WIDTH = 1271;
    public static final int WORLD_HEIGHT = 716;
}
