package com.sidmeier.campuschaos.utils;

public class Coord<X, Y> {
    private final X x;
    private final Y y;

    /**
     * Constructs the data structure, initialising the X and Y values
     * @param x is the x-coordinate to be stored in the data structure
     * @param y is the y-coordinate to be stored in the data structure
     */
    public Coord(X x, Y y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Coord coord = (Coord) o;

        if (x != null ? !x.equals(coord.x) : coord.x != null) return false;
        if (y != null ? !y.equals(coord.y) : coord.y != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = x != null ? x.hashCode() : 0;
        result = 31 * result + (y != null ? y.hashCode() : 0);
        return result;
    }

    /**
     * Used to get access to the HashMap containing the data on all the sectors.
     * @return x coordinate stored in structure
     */
    public X getX() {
        return this.x;
    }

    /**
     * Used to get access to the HashMap containing the data on all the sectors.
     * @return y coordinate stored in structure
     */
    public Y getY() {
        return this.y;
    }
}
