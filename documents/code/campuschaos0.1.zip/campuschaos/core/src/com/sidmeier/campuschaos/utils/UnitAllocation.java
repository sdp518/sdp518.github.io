package com.sidmeier.campuschaos.utils;

import com.sidmeier.campuschaos.Sector;
import java.util.HashMap;

public class UnitAllocation {

    /**
     * Calculates the number of units to be allocated to a player, the sum of:
     * Base rate: Set in Constants class
     * Control Bonus: X extra units per turn for every 5 sectors owned over 20 sectors
     *                (at this point x = 1, can be adjusted by changing Constants.SECTOR_SCALAR)
     * Landmark Bonus: Bonus units for controlling specific sectors, defined within Sector
     * @param currentPlayer The player to which the units will be allocated
     * @param sectors The current state of the map
     * @return the number of units to be allocated
     */
    public int getAllocation(Constants.College currentPlayer, HashMap<Coord<Integer,Integer>,Sector> sectors) {
        int sectorCount = 0;
        int controlBonus = 0;
        int landmarkBonus = 0; //Exists to allow for bonus feature later in development
        for(Sector sector : sectors.values()) {
            if(sector.getAffiliation() == currentPlayer) {
                sectorCount += 1;
                landmarkBonus += sector.getBonus();
            }
        }
        if (sectorCount==0) {
            return 0;
        }
        if (sectorCount>=20) {
            controlBonus = ((int)((sectorCount-20) * Constants.SECTOR_SCALAR));
        }
        else {
            controlBonus = 0;
        }
        return Constants.BASE_TROOPS + controlBonus + landmarkBonus;
    }
}
