package com.sidmeier.campuschaos.utils;

import com.sidmeier.campuschaos.Sector;
import javafx.util.Pair;

import java.util.HashMap;

public class UnitAllocation {

    /**
     * Calculates the number of units to be allocated to a player
     * @param currentPlayer the player to which the units will be allocated
     * @param sectors
     * @return the number of units to be allocated
     */
    public int getAllocation(Constants.College currentPlayer, HashMap<Pair<Integer,Integer>,Sector> sectors) {
        int sectorCount = 0;
        int bonus = 0; //Exists to allow for bonus feature later in development
        for(Sector sector : sectors.values()) {
            if(sector.getAffiliation() == currentPlayer) {
                sectorCount += 1;
                bonus += sector.getBonus();
            }
        }
        if (sectorCount==0) {
            return 0;
        }
        if (sectorCount>=20) {
            sectorCount = ((int)((sectorCount-20) * Constants.SECTOR_SCALAR));
        }
        else {
            sectorCount = 0;
        }
        return Constants.BASE_TROOPS + sectorCount + bonus;
    }
}
