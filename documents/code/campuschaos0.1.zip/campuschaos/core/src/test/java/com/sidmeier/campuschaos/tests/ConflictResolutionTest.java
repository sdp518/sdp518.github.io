package com.sidmeier.campuschaos.tests;

import com.sidmeier.campuschaos.utils.ConflictResolution;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ConflictResolutionTest {

    private ConflictResolution cR;

    @Before
    public void setUp() throws Exception {
        cR = new ConflictResolution();
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void resolveConflict() throws Exception {
        int defendingUnits = 10;
        int defendingMultiplier = 2;
        int attackingUnits = 20;
        int attackingMultiplier = 5;
        for (int i = 0;i<100;i++) {
            assertNotEquals(null, cR.resolveConflict(defendingUnits, defendingMultiplier, attackingUnits, attackingMultiplier));
        }

    }

}