package com.sidmeier.campuschaos.tests;

import com.sidmeier.campuschaos.Sector;
import com.sidmeier.campuschaos.utils.Constants;
import com.sidmeier.campuschaos.utils.UnitAllocation;
import javafx.util.Pair;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.*;

public class UnitAllocationTest {

    private UnitAllocation allocation;
    private HashMap<Pair<Integer, Integer>, Sector> scenario1;
    private HashMap<Pair<Integer, Integer>, Sector> scenario2;
    private HashMap<Pair<Integer, Integer>, Sector> scenario3;
    private HashMap<Pair<Integer, Integer>, Sector> scenario4;
    private HashMap<Pair<Integer, Integer>, Sector> scenario5;

    @Before
    public void setUp() throws Exception {
        Constants.College currentPlayer = Constants.College.CONSTANTINE;
        allocation = new UnitAllocation();
        scenario1 = new HashMap<Pair<Integer, Integer>, Sector>();
        scenario2 = new HashMap<Pair<Integer, Integer>, Sector>();
        scenario3 = new HashMap<Pair<Integer, Integer>, Sector>();
        scenario4 = new HashMap<Pair<Integer, Integer>, Sector>();
        scenario5 = new HashMap<Pair<Integer, Integer>, Sector>();

        for (int i=0;i<3;i++) {
            scenario1.put(new Pair<Integer, Integer>(i,i), new Sector("Sector" + i, 0));
            scenario1.get(new Pair<Integer, Integer>(i,i)).setAffiliation(currentPlayer);
        }

        for (int i=0;i<3;i++) {
            scenario2.put(new Pair<Integer, Integer>(i,i), new Sector("Sector" + i, i));
            scenario2.get(new Pair<Integer, Integer>(i,i)).setAffiliation(currentPlayer);
        }

        for (int i=0;i<26;i++) {
            scenario3.put(new Pair<Integer, Integer>(i,i), new Sector("Sector" + i, 0));
            scenario3.get(new Pair<Integer, Integer>(i,i)).setAffiliation(currentPlayer);
            if (i > 0) {
                scenario3.put(new Pair<Integer, Integer>(i,i+1), new Sector("Sector" + i, 0));
                scenario3.get(new Pair<Integer, Integer>(i,i+1)).setAffiliation(Constants.College.ALCUIN);
            }
            if (i > 1) {
                scenario3.put(new Pair<Integer, Integer>(i+1,i), new Sector("Sector" + i, 0));
                scenario3.get(new Pair<Integer, Integer>(i+1,i)).setAffiliation(Constants.College.DERWENT);
            }
        }

        for (int i=0;i<35;i++) {
            scenario4.put(new Pair<Integer, Integer>(i,i), new Sector("Sector" + i, 1));
            scenario4.get(new Pair<Integer, Integer>(i,i)).setAffiliation(currentPlayer);
        }

        for (int i=0;i<3;i++) {
            scenario5.put(new Pair<Integer, Integer>(i,i), new Sector("Sector" + i, -1));
            scenario5.get(new Pair<Integer, Integer>(i,i)).setAffiliation(currentPlayer);
        }

    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void baseRate() throws Exception {
        Constants.College player1 = Constants.College.CONSTANTINE;
        Constants.College player2 = Constants.College.DERWENT;
        assertEquals(5, allocation.getAllocation(player1, scenario1));
        assertEquals(0, allocation.getAllocation(player2, scenario1));
    }

    @Test
    public void withBonus() throws Exception {
        Constants.College player1 = Constants.College.CONSTANTINE;
        assertEquals(8, allocation.getAllocation(player1, scenario2));
    }

    @Test
    public void withWeight() throws Exception {
        Constants.College player1 = Constants.College.CONSTANTINE;
        Constants.College player2 = Constants.College.DERWENT;
        Constants.College player3 = Constants.College.ALCUIN;
        assertEquals(6, allocation.getAllocation(player1, scenario3));
        assertEquals(6, allocation.getAllocation(player3, scenario3));
        assertEquals(5, allocation.getAllocation(player2, scenario3));
    }

    @Test
    public void weightAndBonus() throws Exception {
        Constants.College player1 = Constants.College.CONSTANTINE;
        assertEquals(43, allocation.getAllocation(player1, scenario4));
    }

    @Test
    public void negativeBonus() throws Exception {
        Constants.College player1 = Constants.College.CONSTANTINE;
        assertEquals(5, allocation.getAllocation(player1, scenario5));
    }

}