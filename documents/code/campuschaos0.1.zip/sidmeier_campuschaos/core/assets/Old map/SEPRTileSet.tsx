<?xml version="1.0" encoding="UTF-8"?>
<tileset name="SEPRTileSet" tilewidth="100" tileheight="100" tilecount="25" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="100" height="100" source="grass.png"/>
 </tile>
 <tile id="1">
  <image width="100" height="100" source="outbounds1.png"/>
 </tile>
 <tile id="2">
  <image width="100" height="100" source="outbounds2.png"/>
 </tile>
 <tile id="3">
  <image width="100" height="100" source="outbounds3.png"/>
 </tile>
 <tile id="4">
  <image width="100" height="100" source="outbounds4.png"/>
 </tile>
 <tile id="5">
  <image width="100" height="100" source="outbounds5.png"/>
 </tile>
 <tile id="6">
  <image width="100" height="100" source="outbounds6.png"/>
 </tile>
 <tile id="7">
  <image width="100" height="100" source="outbounds7.png"/>
 </tile>
 <tile id="8">
  <image width="100" height="100" source="outbounds8.png"/>
 </tile>
 <tile id="9">
  <image width="100" height="100" source="outbounds9.png"/>
 </tile>
 <tile id="10">
  <image width="100" height="100" source="outbounds10.png"/>
 </tile>
 <tile id="11">
  <image width="100" height="100" source="outbounds11.png"/>
 </tile>
 <tile id="12">
  <image width="100" height="100" source="outbounds12.png"/>
 </tile>
 <tile id="13">
  <image width="100" height="100" source="outbounds13.png"/>
 </tile>
 <tile id="14">
  <image width="100" height="100" source="outbounds14.png"/>
 </tile>
 <tile id="15">
  <image width="100" height="100" source="outbounds15.png"/>
 </tile>
 <tile id="16">
  <image width="100" height="100" source="outboundsblank.png"/>
 </tile>
 <tile id="17">
  <image width="100" height="100" source="outboundsdown.png"/>
 </tile>
 <tile id="18">
  <image width="100" height="100" source="outboundsleft.png"/>
 </tile>
 <tile id="19">
  <image width="100" height="100" source="outboundsleftandright.png"/>
 </tile>
 <tile id="20">
  <image width="100" height="100" source="outboundsright.png"/>
 </tile>
 <tile id="21">
  <image width="100" height="100" source="outboundsup.png"/>
 </tile>
 <tile id="22">
  <image width="100" height="100" source="outbounds16.png"/>
 </tile>
 <tile id="23">
  <image width="100" height="100" source="outbounds17.png"/>
 </tile>
 <tile id="26">
  <image width="100" height="100" source="hall.png"/>
 </tile>
</tileset>
