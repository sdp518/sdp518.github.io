package com.sidmeier.campuschaos;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.sidmeier.campuschaos.utils.Coord;
import com.sidmeier.campuschaos.utils.FontGenerator;

public class SectorInformation extends Actor {
    private BitmapFont font;
    private Sector selectedSector;
    private int timer = 0;
    private boolean draw = false;
    private Coord<Float,Float> tileOrigin;
    private SpriteBatch batch = new SpriteBatch();

    /**
     * Constructor
     */
    public SectorInformation( SpriteBatch batch) {
        this.font = new FontGenerator().generateFont("core/assets/FreeMonoBold.ttf", 36);
        this.batch = batch;
    }

    /**
     * ???
     * @param batch
     * @param alpha
     */
    @Override
    public void draw(Batch batch, float alpha) {
        int offset = 18;
        if (this.timer > 0) {
            this.batch.begin();
            if (this.selectedSector.getName() != null) {
                font.draw(this.batch, "Name: " + this.selectedSector.getName(), tileOrigin.getX() + offset, 4.75f*tileOrigin.getY());
            } else {
                font.draw(this.batch, "Name:", tileOrigin.getX() + offset, 4.75f*tileOrigin.getY());
            }
            if (this.selectedSector.getAffiliation() != null) {
                font.draw(this.batch, "College: " + this.selectedSector.getAffiliation().getName(), tileOrigin.getX() + offset, 3.75f*tileOrigin.getY());
            } else {
                font.draw(this.batch, "College:", tileOrigin.getX() + offset, 3.75f*tileOrigin.getY());
            }
            font.draw(this.batch,"Units: " + Integer.toString(this.selectedSector.getAmountOfUnits()),tileOrigin.getX() + offset, 2.75f*tileOrigin.getY());
            font.draw(this.batch,"Bonus: " + Integer.toString(this.selectedSector.getBonus()),tileOrigin.getX() + offset, 1.75f*tileOrigin.getY());
            this.batch.end();
            this.timer--;
            if (this.timer == 0) {
                this.draw = false;
            }
        }
    }

    /**
     * ???
     */
    public void setTileOrigin(Coord<Float,Float> tileOrigin) {
        this.tileOrigin = tileOrigin;
    }

    /**
     * ???
     */
    public void setSector(Sector selectedSector) {
        this.selectedSector = selectedSector;
        this.timer = 60 * 20;
        this.draw = true;
    }

    /**
     * ???
     */
    public void disposeFont(){
        this.font.dispose();
    }

    /**
     * ???
     * @return Boolean
     */
    public boolean isDraw() {
        return this.draw;
    }
}